module.exports = { charge: (a) => ({ ok: true, amount: a }) };
module.exports.refund = (id) => ({ ok: true, id });
module.exports.verifySig = (b,s) => b && s;
