exports.retry = (fn, n=3) => { for (;;) { try { return fn(); } catch(e) { if(!--n) throw e; } } };
